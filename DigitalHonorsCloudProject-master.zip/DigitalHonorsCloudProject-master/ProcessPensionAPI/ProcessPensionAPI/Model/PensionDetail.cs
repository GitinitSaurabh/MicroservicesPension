﻿using System;

namespace ProcessPensionAPI.Model
{
    public class PensionDetail
    {
        public int Id { get; set; }
        public double PensionAmount { get; set; }
        public double BankServiceCharge { get; set; }

    }
}
