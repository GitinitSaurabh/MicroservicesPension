﻿namespace ProcessPensionAPI.Model
{
    public class ProcessPensionInput
    {
        public int Id { get; set; }
        public string AadhaarNumber { get; set; }

    }
}
