﻿namespace ProcessPensionAPI.Const
{
    public class TokenHelper
    {
        public static string TokenString;
    }
}
