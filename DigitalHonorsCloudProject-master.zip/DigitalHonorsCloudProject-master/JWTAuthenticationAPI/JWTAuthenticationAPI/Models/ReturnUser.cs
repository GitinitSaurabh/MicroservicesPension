﻿using System;
namespace JWTAuthenticationAPI.Models
{
    public class ReturnUser
    {
        public string DisplayName { get; set; }
        public string Token { get; set; }
    }
}
