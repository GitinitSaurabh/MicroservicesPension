﻿namespace PensionerDetailAPI.Model
{
    public class BankDetail
    {
        public int Id { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string BankType { get; set; }

    }
}
